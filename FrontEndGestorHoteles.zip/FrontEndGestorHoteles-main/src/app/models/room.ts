export class Room{
    constructor(
        public _id: String,
        public name: String,
        public available: String,
        public price: Number
    ){}
}