export class Service{
    constructor(
        public _id: string,
        public name: String,
        public description: String,
        public price: string
    ){}
}