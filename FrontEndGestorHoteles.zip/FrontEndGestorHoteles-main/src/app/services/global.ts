export const CONNECTION = {
    URI: 'http://localhost:3800/api/'
}