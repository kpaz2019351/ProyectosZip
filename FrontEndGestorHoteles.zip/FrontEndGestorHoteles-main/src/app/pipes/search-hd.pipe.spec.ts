import { SearchHDPipe } from './search-hd.pipe';

describe('SearchHDPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchHDPipe();
    expect(pipe).toBeTruthy();
  });
});
