import { SearchRPipe } from './search-r.pipe';

describe('SearchRPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchRPipe();
    expect(pipe).toBeTruthy();
  });
});
