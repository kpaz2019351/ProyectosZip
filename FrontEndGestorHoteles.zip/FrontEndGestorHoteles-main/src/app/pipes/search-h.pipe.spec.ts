import { SearchHPipe } from './search-h.pipe';

describe('SearchHPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchHPipe();
    expect(pipe).toBeTruthy();
  });
});
